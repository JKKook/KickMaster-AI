const userContent = '2000년생 공격형 미드필더 스페인 선수 추천해주세요';

module.exports = { userContent };
